import {
  Box,
  Container,
  Typography,
  Button,
  Grid,
  Paper,
  Stack,
  Divider,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import Layout from "../components/Layout";

function InfoPanel({ title, desc, actions }) {
  return (
    <Stack
      direction={{ xs: "column", sm: "row" }}
      spacing={2}
      alignItems={{ xs: "stretch", sm: "center" }}
      justifyContent="space-between"
    >
      <Box>
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          {title}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {desc}
        </Typography>
      </Box>
      <Stack direction="row" spacing={1}>
        {actions}
      </Stack>
    </Stack>
  );
}

function AuthedHome({ role = "student" }) {
  const linksByRole = {
    admin: [
      { to: "/dashboard", label: "Dashboard" },
      { to: "/users", label: "Users" },
      { to: "/manage-lessons", label: "Manage Lessons" },
      { to: "/courses", label: "Courses" },
      { to: "/notifications", label: "Notifications" },
      { to: "/analytics", label: "Analytics" },
    ],
    teacher: [
      { to: "/dashboard", label: "Dashboard" },
      { to: "/users", label: "Users" },
      { to: "/manage-lessons", label: "Manage Lessons" },
      { to: "/courses", label: "Courses" },
      { to: "/suggest", label: "Suggest Lesson" },
      { to: "/notifications", label: "Notifications" },
    ],
    student: [
      { to: "/dashboard", label: "Dashboard" },
      { to: "/lessons", label: "My Lessons" },
      { to: "/courses", label: "Courses" },
      { to: "/suggest", label: "Suggest Lesson" },
      { to: "/notifications", label: "Notifications" },
    ],
  };

  const tiles = linksByRole[role] || linksByRole.student;

  return (
    <Layout role={role}>
      <Container maxWidth="lg" sx={{ py: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 600, mb: 1 }}>
          Welcome back 👋
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Use the quick actions below or the sidebar to navigate.
        </Typography>

        {/* Quick Actions */}
        <Grid container spacing={2}>
          {tiles.map((t) => (
            <Grid item xs={12} sm={6} md={4} key={t.to}>
              <Paper
                variant="outlined"
                sx={{
                  p: 2,
                  height: "100%",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
                  {t.label}
                </Typography>
                <Typography variant="body2" sx={{ flexGrow: 1, opacity: 0.8 }}>
                  Go to {t.label.toLowerCase()}.
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Button
                    component={RouterLink}
                    to={t.to}
                    variant="contained"
                    size="small"
                  >
                    Open
                  </Button>
                </Box>
              </Paper>
            </Grid>
          ))}
        </Grid>

        {/* Helpful panels */}
        <Paper variant="outlined" sx={{ mt: 3, p: 2 }}>
          <InfoPanel
            title="Need to coordinate a time?"
            desc="Use the Suggest tool to find mutually free slots (Greedy or Backtracking)."
            actions={
              <>
                <Button
                  component={RouterLink}
                  to="/suggest"
                  variant="contained"
                  size="small"
                >
                  Open Suggest
                </Button>
                <Button
                  component={RouterLink}
                  to="/availability"
                  variant="outlined"
                  size="small"
                >
                  My Availability
                </Button>
              </>
            }
          />

          <Divider sx={{ my: 2 }} />

          <InfoPanel
            title="Chat & Messages"
            desc="Start a private chat from Users, or open course chat from a course page."
            actions={
              <>
                <Button
                  component={RouterLink}
                  to="/users"
                  variant="outlined"
                  size="small"
                >
                  Browse Users
                </Button>
                <Button
                  component={RouterLink}
                  to="/courses"
                  variant="outlined"
                  size="small"
                >
                  Course Chat
                </Button>
                <Button
                  component={RouterLink}
                  to="/notifications"
                  variant="outlined"
                  size="small"
                >
                  Notifications
                </Button>
              </>
            }
          />
        </Paper>
      </Container>
    </Layout>
  );
}

function PublicHome() {
  return (
    <Box
      sx={{ minHeight: "100vh", display: "grid", placeItems: "center", p: 3 }}
    >
      <Container maxWidth="md" sx={{ textAlign: "center" }}>
        <Typography variant="h3" sx={{ fontWeight: 700, mb: 1 }}>
          Music College
        </Typography>
        <Typography variant="h6" color="text.secondary" sx={{ mb: 3 }}>
          Lessons, courses, materials, chat, and scheduling — all in one place.
        </Typography>
        <Stack
          direction={{ xs: "column", sm: "row" }}
          spacing={2}
          justifyContent="center"
        >
          <Button
            component={RouterLink}
            to="/login"
            variant="contained"
            size="large"
          >
            Log In
          </Button>
          <Button
            component={RouterLink}
            to="/signup"
            variant="outlined"
            size="large"
          >
            Sign Up
          </Button>
        </Stack>
      </Container>
    </Box>
  );
}

export default function Home() {
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role") || "student";
  return token ? <AuthedHome role={role} /> : <PublicHome />;
}
