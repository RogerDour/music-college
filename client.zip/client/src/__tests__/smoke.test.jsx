// client/src/__tests__/smoke.test.jsx
import { expect, test } from "vitest";
test("testing works", () => {
  expect(1 + 1).toBe(2);
});
