import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: {
          signup: "Sign Up",
          login: "Log In",
          name: "Name",
          email: "Email",
          password: "Password",
          createAccount: "Create Account",
          fillFields: "Please fill in all required fields",
          signupSuccess: "Account created successfully!",
          signupFailed: "Signup failed. Please try again.",
          loginFailed: "Login failed. Check credentials.",
          somethingWentWrong: "Something went wrong.",
          welcome: "Welcome",
        },
      },
      he: {
        translation: {
          signup: "הרשמה",
          login: "התחברות",
          name: "שם",
          email: "אימייל",
          password: "סיסמה",
          createAccount: "צור חשבון",
          fillFields: "אנא מלא את כל השדות הדרושים",
          signupSuccess: "החשבון נוצר בהצלחה!",
          signupFailed: "הרשמה נכשלה. נסה שוב.",
          loginFailed: "ההתחברות נכשלה. בדוק את הפרטים.",
          somethingWentWrong: "משהו השתבש.",
          welcome: "ברוך הבא",
        },
      },
    },
    lng: "en",
    fallbackLng: "en",
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;
